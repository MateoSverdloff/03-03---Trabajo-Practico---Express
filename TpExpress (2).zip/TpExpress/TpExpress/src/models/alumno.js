export default class Alumno  {
    constructor(username, edad, dni){
        this.username = username;
        this.edad = edad;
        this.dni = dni;
    }
    }     
    
    function getUsername(){
        return this.username;
    }
    
    function getEdad(){

        return this.edad;
    }
    
    function getDni(dniB){
    }
    
    function getData(){
        return`nombre:${this.username},edad:${this.edad},dni: ${this.dni}`;
    }

    