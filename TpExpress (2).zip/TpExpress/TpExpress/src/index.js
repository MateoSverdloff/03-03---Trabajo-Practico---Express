import Alumno from "./models/alumno.js" 
import {PI,suma, resta, multiplicacion, division} from "./modules/matematica.js" 
import {OMDBSearchByPage, OMDBSearchComplete, OMDBGetByImdbID} from "./modules/omdb-wraper.js"
import express from "express";
import cors from "cors";

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
    res.send('Ya estoy respondiendo!');
})

let nombre;

app.get("/saludar/:nombre",(req,res)=>{ 
    res.send(`Hola ${req.params.nombre}`); 
})

app.listen(port,()=>{ 
    console.log(`Exampleapplisteningonport${port}`) 
})


app.get("/matematica/sumar",(req,res) => {
    let n1 = parseInt(req.query.n1);
    let n2 = parseInt(req.query.n2);
    let resultado = suma(n1,n2) 

    res.send(`Resultado=${resultado}`)
})

app.get("/matematica/restar",(req,res) => {
    let n1 = parseInt(req.query.n1);
    let n2 = parseInt(req.query.n2);
    let resultado = resta(n1,n2) 

    res.send(`Resultado=${resultado}`)
})

app.get("/matematica/multi",(req,res) => {
    let n1 = parseInt(req.query.n1);
    let n2 = parseInt(req.query.n2);
    let resultado = multiplicacion(n1,n2) 

    res.send(`Resultado=${resultado}`)
})

app.get("/matematica/divi",(req,res) => {
    let n1 = parseInt(req.query.n1);
    let n2 = parseInt(req.query.n2);
    let resultado = division(n1,n2) 
    res.send(`Resultado=${resultado}`)
})

app.get("/omdb-wraper/result", async(req,res) => {
    let text = req.query.text;
    let page= req.query.page;
    let result  = await OMDBSearchByPage(text,page)
    res.send(result)
})

app.get("/omdb-wraper/complete", async(req,res) => {
    let text = req.query.text;
    let page= req.query.page;
    let result  = await OMDBSearchComplete(text,page)
    res.send(result)
})

app.get("/omdb-wraper/byId", async (req, res) => {
    let id = req.query.id;
    let result = await OMDBGetByImdbID(id);
    res.send(result);
});

//FALTA LO DE ALUMNOS Y YA ESTA !!!!
app.get("/alumnos",(req,res) => {
res.send(alumnosArray);
})

app.get("/alumnos/:dni",(req, res) => {
    let dniB = req.params.dni
    console.log('dniB', dniB)
    let resultana = alumnosArray.find(( alumno ) => alumno.edad===20);
    console.log('resultana', resultana)
    res.send(resultana);
})
    

const alumnosArray=[];
alumnosArray.push(new Alumno("EstebanDido" ,"22888444",20)); 
alumnosArray.push(new Alumno("MatiasQueroso","28946255",51)); 
alumnosArray.push(new Alumno("ElbaCalao" ,"32623391",18));

// app.post("/alumnnos"{

// })