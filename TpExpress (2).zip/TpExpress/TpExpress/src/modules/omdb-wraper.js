import axios from "axios";

const APIKEY = "69ebd2ea";

const OMDBSearchByPage = async (searchText, page) => {
    let returnObject ={
        respuesta : false,
        cantidadTotal: 0,
        datos: []
    };

    const requestString = `http://www.omdbapi.com/?apikey=${APIKEY}&s=${searchText}&page=${page}`;

    try{
        const responseData = await axios.get(requestString);
        returnObject.datos = responseData.data.Search || [];
        returnObject.cantidadTotal = responseData.data.totalResults || 0;
        returnObject.respuesta = true;
    } catch (error) {
        console.error("Error al hacer el request", error);
    }
    return returnObject;
};

export default OMDBSearchByPage;

const OMDBSearchComplete = async (searchText,page) => {
    let returnObject = {
        respuesta : false,
        cantidadTotal: 0,
        datos: {}
    };

    const requestString = `http://www.omdbapi.com/?apikey=${APIKEY}&s=${searchText}&page=${page}`;

    try{
        const responseData = await axios.get(requestString);
        returnObject.datos = responseData.data.Search;
        returnObject.cantidadTotal = returnObject.datos.totalResults;
    } catch (error) {
        console.error("error al hacer el request", error);
    }

    return returnObject;
};

const OMDBGetByImdbID = async (imdbID) => {
    let returnObject = {
        respuesta: false,
        cantidadTotal: 0,
        datos: {}
    };

    const requestString = `http://www.omdbapi.com/?apikey=${APIKEY}&i=${imdbID}`;

    try {
        const responseData = await axios.get(requestString);
        returnObject.datos = responseData.data;
        returnObject.respuesta = true;
        returnObject.cantidadTotal = 1;
    } catch (error) {
        console.error("Error al hacer la request: ", error);
    }

    return returnObject;
};

export { OMDBSearchByPage, OMDBSearchComplete, OMDBGetByImdbID};




